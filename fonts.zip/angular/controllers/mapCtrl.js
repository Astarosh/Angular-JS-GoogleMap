app.controller("mapCtrl", ["$scope", "$http", "$location", "$compile", function ($scope, $http, $location, $compile) {
	"use strict";
	//console.log("Ok");
	$scope.markers = [];
	$scope.features = [];
	$scope.infowindow = new google.maps.InfoWindow();
	$scope.infowindowTemplate =
		'<div class="text-center">' +
			'<label for="eventName">Введите название мероприятия</label>' +
			'<div class="input-group">' +
				'<input type="text" class="form-control" name="" placeholder="Введите название мероприятия" required ng-model="eventName" value="" size="20" required>' +
				'<span class="input-group-addon info" ng-click="saveMarkerInfo(eventName)" tooltip-placement="top-right" uib-tooltip="Для сохранения нажмите"><span class="glyphicon glyphicon-save"></span></span>' +
			'</div>' +
			'<label for="eventDate">Введите дату проведения</label>' +
			'<div class="input-group">' +
				'<input type="date" class="form-control" name="eventDate" placeholder="Введите дату проведения" required ng-model="eventDate" value="" size="20" required>' +
				'<span class="input-group-addon info" ng-click="saveMarkerInfo(eventDate)" tooltip-placement="top-right" uib-tooltip="Для сохранения нажмите"><span class="glyphicon glyphicon-save"></span></span>' +
			'</div>' +
		    '<label for="eventDate">Введите время проведения</label>' +
			'<div class="input-group">' +
				'<input type="time" class="form-control" name="eventTime" placeholder="Введите дату проведения" required ng-model="eventTime" value="" size="20" required>' +
				'<span class="input-group-addon info" ng-click="saveMarkerInfo(eventTime)" tooltip-placement="top-right" uib-tooltip="Для сохранения нажмите"><span class="glyphicon glyphicon-save"></span></span>' +
			'</div>' +
			'<label for="eventType">Выберите тип мероприятия</label>' +
			'<div class="input-group">' +
				'<select class="form-control" ng-model="eventType" ng-options="item for item in eventTypes"></select>' +
				'<span class="input-group-addon info" ng-click="saveMarkerInfo(selectedName)" tooltip-placement="top-right" uib-tooltip="Для сохранения нажмите"><span class="glyphicon glyphicon-save"></span></span>' +
			'</div>' +
			'<label for="eventType">Введите дополнительную информацию</label>' +
			'<div class="input-group">' +
				'<textarea class="form-control text-center" ng-model="additionInfo" maxlength=100 cols=100></textarea>' +
				'<span class="input-group-addon info" ng-click="saveMarkerInfo(selectedName)" tooltip-placement="top-right" uib-tooltip="Для сохранения нажмите"><span class="glyphicon glyphicon-save"></span></span>' +
			'</div>' +
			'</br><button id="saveMarkerButton" class="btn btn-success pull-left" ng-click="saveMarker()">Сохранить</button>' +
			'<button class="btn btn-success pull-right" id="deletemarker">Удалить</button>' +
		'</div>';
	$scope.input = document.getElementById('pac-input');
    $scope.searchBox = new google.maps.places.SearchBox($scope.input);
	$scope.myLatlng = new google.maps.LatLng(53.903, 27.560);
	$scope.mapOptions = {
		zoom: 11,
		center: new google.maps.LatLng(53.904, 27.544),
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		mapTypeControlOptions: {
			style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
		}
	};
	$scope.mapContainer = document.getElementById("MyMap");
	$scope.map = new google.maps.Map($scope.mapContainer, $scope.mapOptions);
	$scope.eventTypes = ["Бар", "Кафе", "Ресторан"];
	//Загружаем файл
    $scope.map.data.loadGeoJson('stations.json');
	//Скрываем слой данных
	$scope.map.data.setStyle(function(feature) {
            return {
		        visible:true
		        //title:feature.getProperty('note'),
		        //icon:feature.getProperty('type')
		    };
        });
		//Получение данных geoJson и преобразование их в маркеры, добавление их в массив
	$scope.map.data.forEach(function (feature) {
		    console.log("ok");
		    var Latlng = feature.getGeometry().get();
            var marker = new google.maps.Marker({    
                position: Latlng,
				icon: feature.getProperty('type'),
				title: "ululu",
				customInfo1: feature.getProperty("userid"),
				customInfo2: feature.getId(),
				customInfo3: feature.getProperty("name")
            });
            markers.push(marker);		  
			marker.addListener('click', function() {
                $scope.map.setZoom(12);
                $scope.map.setCenter(marker.getPosition());
				//var userIDcookie = get_cookie("id");	
				if(marker.customInfo1 == userIDcookie){
			        $scope.infowindow.setContent("<form action='deleteFeature.php' method='POST'>"+
				    "<input id='featureID' name='featureID' value="+marker.customInfo2+" />"+
				    "<div style='color:black' style='width:150px; text-align: center;'>"+marker.customInfo3+"</div>"+
			        "<button id='deleteFeature'>Удалить</button>"+
				    "</form>");
				}
                else{
			        $scope.infowindow.setContent("<div style='width:150px; text-align: center;'>"+marker.customInfo3+"</div>");
			    };			
                $scope.infowindow.open($scope.map, marker);
            });
		});
	$scope.saveMarker = function () {
		if ($scope.eventType === "Бар") {
			$scope.eventType = "img/bar.png";
		} else if ($scope.eventType === "Кафе") {
			$scope.eventType = "img/coffe.png";
		} else if ($scope.eventType === "Ресторан") {
			$scope.eventType = "img/restaurant.png";
		}
		//console.log($scope.placedMarkerLat);
		//console.log($scope.placedMarkerLng);
		if ($scope.id !== null && $scope.id !== undefined && $scope.id !== "") {
			//console.log($scope.eventTime.toISOString());
			//console.log($scope.eventTime.toISOString().slice(11, -8));
			$http.post("php/saveMarker.php", {"id": $scope.id, "userhash": $scope.userhash, "eventName": $scope.eventName, "eventDate": $scope.eventDate.toISOString().slice(0, 10), "eventTime": $scope.eventTime.toISOString().slice(11, -5), "eventType": $scope.eventType, "additionInfo": $scope.additionInfo, "eventLat": $scope.placedMarkerLat, "eventLng": $scope.placedMarkerLng})
			.success(function (data, status, header, config) {
				console.log("All done");
				$scope.saveProfileInfoDataResponse = data;
				console.log($scope.saveProfileInfoDataResponse);
				//$scope.setCookies($scope.saveProfileInfoDataResponse);
			})
			.error(function(data, status) {
				console.error('Repos error', status, data);
			})
		} else {
			document.getElementById("saveMarkerButton").innerHTML = "Войдите или зарегистрируйтесь";
		}
	};
	$scope.addOpenInfoWindowEvent = function (placedMarker) {
		placedMarker.addListener('click', function () {
			$scope.placedMarkerLat = placedMarker.position.lat();
			$scope.placedMarkerLng = placedMarker.position.lng();
			console.log($scope.placedMarkerLat);
			console.log($scope.placedMarkerLng);
			$scope.templateCompiled = $compile($scope.infowindowTemplate)($scope);
			$scope.infowindow.close();
			$scope.infowindow = new google.maps.InfoWindow();
			$scope.infowindow.setContent($scope.templateCompiled[0]);
			$scope.infowindow.open($scope.map, placedMarker);
		});
	};
	$scope.deleteMark = function () {
		$scope.marker.setMap(null);
	};
	$scope.placeMarker = function (location) {
		$scope.templateCompiled = $compile($scope.infowindowTemplate)($scope);
		if (location !== undefined) {
			//console.log(location);
			//scope.infowindow.open(map, marker);
			$scope.placedMarker = new google.maps.Marker({
				position: location,
				draggable: false,
				map: $scope.map,
				animation: google.maps.Animation.DROP,
				title: 'Uluru (Ayers Rock)'
			});
			$scope.placedMarkerLat = location.lat();
			$scope.placedMarkerLng = location.lng();
			console.log($scope.placedMarkerLat);
			console.log($scope.placedMarkerLng);
			$scope.infowindow = new google.maps.InfoWindow();
			$scope.infowindow.setContent($scope.templateCompiled[0]);
			$scope.infowindow.open($scope.map, $scope.placedMarker);
			//console.log($scope.infowindow.content);
			$scope.markers.push($scope.placedMarker);
			$scope.addOpenInfoWindowEvent($scope.placedMarker);
		} else {
			console.log("Что-то не то в placeMarker");
		}
		//console.log($scope.markers);
	};
	google.maps.event.addListener($scope.map, 'dblclick', function (event) {
		$scope.infowindow.close();
		$scope.placeMarker(event.latLng);
	});
	google.maps.event.addListener($scope.map, 'click', function () {
		$scope.infowindow.close();
	});
}]);