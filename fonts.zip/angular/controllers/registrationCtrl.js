app.controller("registrationCtrl", ["$scope", "$http", "$location", "$cookies", "$cookieStore", "$filter", function ($scope, $http, $location, $cookies, $cookieStore, $filter) {
	"use strict";
	$scope.birthdate = new Date();
	$scope.id = ["regname", "regusername", "reglastname", "regpassword", "regpassword2", "regstreet", "regcity", "regprovince"];
	$scope.idShort = ["regname2", "reglastname2", "regpassword3", "regpassword4"];
	$scope.enterpassword = "Введите пароль";
	$scope.regUsername = "";
	$scope.regName = "";
	$scope.regLastname = "";
	$scope.regPassword = "";
	$scope.regPassword2 = "";
	$scope.regEmail = "";
	$scope.regStreet = "";
	$scope.regCity = "";
	$scope.regProvince = "";
    $scope.modalTitleButton = " Простая регистрация";
	$scope.fullOrShort = true;
	$scope.modalTitle = "Регистрация на сайте(полная)";
	$scope.colorLightGreen = "lightgreen";
	$scope.colorRed = "red";
	$scope.gRecaptchaResponse = null;
	$scope.fullOrShortRegistration = function () {
		$scope.modalTitle = $scope.modalTitle === "Регистрация на сайте(полная)" ? "Регистрация на сайте(простая)" : "Регистрация на сайте(полная)";
		$scope.modalTitleButton = $scope.modalTitleButton === " Полная регистрация" ? " Простая регистрация" : " Полная регистрация";
		$scope.fullOrShort = $scope.modalTitleButton === " Полная регистрация" ? false : true;
	};
	//$scope.now = new Date();
	//$scope.exp = new Date($scope.now.getFullYear(), $scope.now.getMonth() + 1);
	$scope.fullRegistration = function () {
		if ($scope.gRecaptchaResponse !== null) {
			//console.log($scope.gRecaptchaResponse);
			if ($scope.regPassword === $scope.regPassword2) {
			    $http.post("php/fullRegistration.php", {"name": $scope.regName, "username": $scope.regUsername, "lastname": $scope.regLastname, "password": $scope.regPassword, "email": $scope.regEmail, "birthdate": $scope.birthdate.toISOString().slice(0, 10), "street": $scope.regStreet, "city": $scope.regCity, "province": $scope.regProvince})
			    .success(function (data, status, header, config) {
				    $scope.fullRegistrationDataResponse = data;
				    if ($scope.fullRegistrationDataResponse.id !== null && $scope.fullRegistrationDataResponse.id !== undefined && $scope.fullRegistrationDataResponse.id !== "") {
					//$scope.setloginTrueOrFalse("true");
				        $scope.setCookies($scope.fullRegistrationDataResponse);
					    $scope.loadUserImages($scope.fullRegistrationDataResponse.id, $scope.fullRegistrationDataResponse.userhash);
				        $location.path(' ');
				    } else {
					    console.log($scope.fullRegistrationDataResponse);
				    }
			    });
			} else {
				$scope.regPassword2 = "";
				$scope.enterpassword = "Неверный пароль";
			}
		}
	};
	$scope.simpleRegistration = function () {
		if ($scope.gRecaptchaResponse !== null) {
			if ($scope.regPassword === $scope.regPassword2) {
				$http.post("php/simpleRegistration.php", {"name": $scope.regName, "lastname": $scope.regLastname, "password": $scope.regPassword, "email": $scope.regEmail})
				.success(function (data, status, header, config) {
					$scope.simpleRegistrationDataResponse = data;
					if ($scope.simpleRegistrationDataResponse.id !== null && $scope.simpleRegistrationDataResponse.id !== undefined && $scope.simpleRegistrationDataResponse.id !== "") {
						//$scope.setloginTrueOrFalse("true");
					    $scope.setCookies($scope.simpleRegistrationDataResponse);
						$scope.loadUserImages($scope.simpleRegistrationDataResponse.id, $scope.simpleRegistrationDataResponse.userhash);
					    $location.path(' ');
					} else {
						console.log($scope.simpleRegistrationDataResponse);
					}
				});
			} else {
				$scope.regPassword2 = "";
				$scope.enterpassword = "Неверный пароль";
			}
		}
	};
	$scope.colorChangeFullReg = function () {
		$scope.elemregEmail = document.getElementById("regEmailColor");
		$scope.elemregEmail.style.backgroundColor = $scope.elemregEmail.children[0].classList.contains("glyphicon-thumbs-up") ? $scope.colorLightGreen : $scope.colorRed;
	};
	$scope.colorChangeShortReg = function () {
		$scope.elemregEmail2 = document.getElementById("regEmailColor2");
		$scope.elemregEmail2.style.backgroundColor = $scope.elemregEmail2.children[0].classList.contains("glyphicon-thumbs-up") ? $scope.colorLightGreen : $scope.colorRed;
	};
	$scope.elemregBirthdate = document.getElementById("regBirthdate");
	$scope.elemregBirthdate.nextElementSibling.style.backgroundColor = $scope.colorLightGreen;
	$scope.disableButton = true;
	$scope.isvalid = function (z) {
		var i = 0;
		for (i; i < $scope.id.length; i++) {
			if ((document.getElementById($scope.id[i]).value + "") === null || (document.getElementById($scope.id[i]).value + "").length < 4 || (document.getElementById($scope.id[i]).value + "").length > 30 || (document.getElementById($scope.id[($scope.id.length - i - 1)]).value + "") === null || (document.getElementById($scope.id[($scope.id.length - i - 1)]).value + "").length < 4 || (document.getElementById($scope.id[($scope.id.length - i - 1)]).value + "").length > 30) {
				$scope.disableButton = true;
			} else {
				$scope.disableButton = false;
			}
		}
		if ((document.getElementById(z).value + "") === null || (document.getElementById(z).value + "").length < 4 || (document.getElementById(z).value + "").length > 30) {
			document.getElementById(z).nextElementSibling.children[0].className = "glyphicon glyphicon-alert";
			document.getElementById(z).nextElementSibling.style.backgroundColor = "red";
		} else {
			document.getElementById(z).nextElementSibling.children[0].className = "glyphicon glyphicon-thumbs-up";
			document.getElementById(z).nextElementSibling.style.backgroundColor = "lightgreen";
		}
	};
	$scope.disableButton2 = true;
	$scope.isvalid2 = function (z) {
		var j = 0;
		for (j; j < $scope.idShort.length; j++) {
			if ((document.getElementById($scope.idShort[j]).value + "") === null || (document.getElementById($scope.idShort[j]).value + "").length < 4 || (document.getElementById($scope.idShort[j]).value + "").length > 30 || (document.getElementById($scope.idShort[($scope.idShort.length - j - 1)]).value + "") === null || (document.getElementById($scope.idShort[($scope.idShort.length - j - 1)]).value + "").length < 4 || (document.getElementById($scope.idShort[($scope.idShort.length - j - 1)]).value + "").length > 30) {
				$scope.disableButton2 = true;
			} else {
				$scope.disableButton2 = false;
			}
		}
		if ((document.getElementById(z).value + "") === null || (document.getElementById(z).value + "").length < 4 || (document.getElementById(z).value + "").length > 30) {
			document.getElementById(z).nextElementSibling.children[0].className = "glyphicon glyphicon-alert";
			document.getElementById(z).nextElementSibling.style.backgroundColor = "red";
		} else {
			document.getElementById(z).nextElementSibling.children[0].className = "glyphicon glyphicon-thumbs-up";
			document.getElementById(z).nextElementSibling.style.backgroundColor = "lightgreen";
		}
	};
}]);