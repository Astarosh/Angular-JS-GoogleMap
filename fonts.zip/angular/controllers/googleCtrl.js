app.controller('GoogleCtrl', ["$scope", "$http", "$cookies", "$cookieStore", "$location", function ($scope, $http, $cookies, $cookieStore, $location) {
	"use strict";
	function onSignIn(googleUser) {
		var profile = googleUser.getBasicProfile();
		//console.log('ID: ' + profile.getId());
		//$scope.idtoken = googleUser.getAuthResponse().id_token;
/*		$scope.name = profile.getGivenName();
		$scope.surname = profile.getFamilyName();
		$scope.email = profile.getEmail();
		$scope.imgUrl = profile.getImageUrl();*/
		$scope.GoogleLogIn = function () {
			console.log($scope.userhash);
			$http.post("php/GoogleLogin.php", {
				"email": profile.getEmail(),
				"name": profile.getGivenName(),
				"surname": profile.getFamilyName(),
				"userhash": $scope.userhash
			}).success(function (data, status, header, config) {
				$scope.GoogleDataResponse = data;
				console.log($scope.GoogleDataResponse);
				$scope.setCookies($scope.GoogleDataResponse);
				$scope.loadUserImages($scope.GoogleDataResponse.id, $scope.GoogleDataResponse.userhash);
			})
			.error(function (data, status) {
            console.error('Repos error', status, data);
		    });
			//$location.path(' ');
		};
		$scope.GoogleLogIn();
	}
	window.onSignIn = onSignIn;
}]);