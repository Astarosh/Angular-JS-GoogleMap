app.controller("MyControllerCtrl", ["$scope", "$http", "$cookies", "$cookieStore", "screenSize", "$location", function ($scope, $http, $cookies, $cookieStore, screenSize, $location) {
	"use strict";
	//Проверка экрана
	if (screenSize.is('xs, sm')) {
		var z = document.getElementsByClassName("buttontog");
		var i = 0;
		for (i; i < z.length; i++) {
			z[i].setAttribute("data-toggle", "collapse");
			z[i].setAttribute("data-target", "#navbar-collapse-1");
		}
		$scope.showInputGroup = false;
	} else {
		$scope.showInputGroup = true;
	}
	//Объявление переменных
	$scope.now = new Date();
	$scope.exp = new Date($scope.now.getFullYear(), $scope.now.getMonth() + 1);
	$scope.passPlaceholder = "Пароль";
	$scope.loginTrueOrFalse = false;
	$scope.avatar = "img/baseAvatar.jpg";
	$scope.showAvatar = true;
	//Загрузка картинок пользователя
	$scope.userImages = [
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
	];
	//Устанавливаем картинки в $scope.userImages
	$scope.setImportedImage = function (ImportedImages) {
		angular.forEach(ImportedImages, function (value, key) {
			$scope.userImages[key] = {};
			$scope.userImages[key] = value;
		});
		if (ImportedImages.length > 4) {
			var i;
			for (i = ImportedImages.length; i < $scope.userImages.length; i++) {
				$scope.userImages.pop();
			}
		}
	};
	//Загружаем картинки
	$scope.loadUserImages = function (id, userhash) {
			$http.post("php/loadUserImages.php", {
			"id": id,
			"userhash": userhash
		}).success(function (data, status, header, config) {
			$scope.loadUserImagesDataResponse = data;
			if ($scope.loadUserImagesDataResponse !== "null" && $scope.loadUserImagesDataResponse !== "undefined") {
				$scope.setImportedImage($scope.loadUserImagesDataResponse);
			} else {
			}
		})
		.error(function (data, status) {
            console.error('Repos error', status, data);
		});
	};
	$scope.loginfalse = function () {
	};
	//Выход пользователя
	$scope.exit = function () {
		$scope.allcookies = $cookies.getAll();
        angular.forEach($scope.allcookies, function (v, k) {
            $cookies.remove(k);
        });
        var auth2 = gapi.auth2.getAuthInstance();
        auth2.signOut();
		$scope.password = "";
		$scope.loginTrueOrFalse = false;
	};
	//Логин пользователей
	$scope.loginform = function () {
		$scope.LoginButton = true;
		$http.post("php/insert.php", {
			"id": $scope.id,
			"userhash": $scope.userhash,
			"email": $scope.email,
			"password": $scope.password
		}).success(function (data, status, header, config) {
			$scope.LoginDataResponse = data;
			console.log($scope.LoginDataResponse);
			if ($scope.LoginDataResponse.userhash !== null && $scope.LoginDataResponse.userhash !== undefined) {
				$scope.setCookies($scope.LoginDataResponse);
				$scope.loadUserImages($scope.LoginDataResponse.id, $scope.LoginDataResponse.userhash);
			} else {
				$scope.password = "";
				$scope.passPlaceholder = "Неверный пароль или email";
			}
			$scope.LoginButton = false;
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
			$scope.LoginButton = true;
		});
		//$location.path(' ');
	};
	//Установка куков и данных $scope
	$scope.setCookies = function (dataResponse) {
		angular.forEach(dataResponse, function (value, key) {
			if (key === "avatar") {
				if (value !== null && value !== undefined) {
					$scope.avatar = value;
		            $scope.showAvatar = true;
				} else {
					$scope.avatar = "img/baseAvatar.jpg";
		            $scope.showAvatar = true;
				}
			} else if (key === "birthdate") {
				if (value === null) {
					$scope[key] = "";
				} else {
					$scope[key] = new Date(value);
				}
			} else if (key === "userhash") {
				if (value === null) {
					$scope[key] = "";
				} else {
					$scope[key] = value;
				    $cookies.put(key, value, {expires: $scope.exp});
				}
			} else if (key === "id") {
				if (value === null) {
					$scope[key] = "";
				} else {
					$scope[key] = value;
				    $cookies.put(key, value, {expires: $scope.exp});
				}
			} else {
		        $scope[key] = value;
		    }
		});
		$scope.loginTrueOrFalse = true;
		//$location.path(' ');
	};
	//Проверка куков юзера
	if ($cookies.get("userhash") !== null && $cookies.get("id") !== undefined && $cookies.get("id") !== null && $cookies.get("userhash") !== undefined) {
		$scope.password = "";
		$scope.id = $cookies.get("id");
		$scope.userhash = $cookies.get("userhash");
		$scope.email = "";
		$scope.loginform();
	} else {
		$scope.userhash = "new";
		$scope.id = "";
	}
}]);