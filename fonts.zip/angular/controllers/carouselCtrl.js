app.controller("carouselCtrl", ["$scope", "$http", "$location", function ($scope, $http, $location) {
	'use strict';
}]);