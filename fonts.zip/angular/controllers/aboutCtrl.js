app.controller("AboutCtrl", ["$scope", "$http", "$location", function ($scope, $http, $location) {	$http.get('question.json').success(function (data, status, header, config) {
		$scope.question = data;
	}).error(function (data, status, headers, config) {
		$scope.notice = status + " " + data.error;
	});
}]);