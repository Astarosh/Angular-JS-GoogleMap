app.controller("profileCtrl", ["$scope", "$http", "$cookies", "$cookieStore", "screenSize", "$location", function ($scope, $http, $cookies, $cookieStore, screenSize, $location) {
	"use strict";
	$(":file").filestyle({input: false, buttonText: "Загрузить фото"});
	$scope.imagesCarouselProfileUrl = [
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
	];
	$scope.SaveAvatarButton = document.getElementById("SaveAvatarButton");
	$scope.SaveAvatarButtonDisabled = true;
	$scope.saveImportedImageButtonDisabled = true;
	$scope.altImageText = "";
	$scope.trueOrFalse = false;
	$scope.showProfileCarouselPhoto = function (x) {
		$scope.saveImportedImageButtonDisabled = false;
		$scope.trueOrFalse = !x;
	};
	$scope.ShowHideAvatar = function () {
		$scope.SaveAvatarButton = document.getElementById("SaveAvatarButton");
		$scope.SaveAvatarButton.innerHTML = "Сохранить фото";
		$scope.showAvatar = false;
		$scope.SaveAvatarButtonDisabled = false;
	};
	$scope.saveImportedImage = function (z) {
		$scope.dummy2.images = [];
		//console.log(z);
		if ($("#owlCarouselProfile").data('owlCarousel') !== undefined && $("#owlCarouselProfile").data('owlCarousel') !== null) {
			$("#owlCarouselProfile").data('owlCarousel').destroy();
		}
		//console.log($("#owlCarouselProfile").data('owlCarousel'));
		var i;
		for (i = 0; i < 5; i++) {
			$scope.imagesCarouselProfileUrl[i] = {};
			if (z[i] !== null && z[i] !== undefined && z[i].length < 1024000) {
				$scope.imagesCarouselProfileUrl[i].imageUrl = z[i];
				//console.log($scope.imagesCarouselProfileUrl);
			} else {
				$scope.imagesCarouselProfileUrl[i].imageUrl = null;
				//console.log($scope.imagesCarouselProfileUrl);
			}
		}
		$http.post("php/saveImportedImage.php", {"id": $scope.id, "url1": $scope.imagesCarouselProfileUrl[0].imageUrl, "url2": $scope.imagesCarouselProfileUrl[1].imageUrl, "url3": $scope.imagesCarouselProfileUrl[2].imageUrl, "url4": $scope.imagesCarouselProfileUrl[3].imageUrl, "url5": $scope.imagesCarouselProfileUrl[4].imageUrl})
        .success(function (data, status, header, config) {
			$scope.saveImportedImageButtonDisabled = true;
			$scope.saveImportedImageDataResponse = data;
			//console.log($scope.saveImportedImageDataResponse);
			if($scope.saveImportedImageDataResponse[0].userId !== null && $scope.saveImportedImageDataResponse[0].userId !== undefined && $scope.saveImportedImageDataResponse[0].userId !== ""){
			$scope.imagesCarouselProfileUrl = [
				{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
				{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
				{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
				{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
				{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
	        ];
				$scope.setImportedImage($scope.imagesCarouselProfileUrl);
				$scope.setImportedImage($scope.saveImportedImageDataResponse);
			    //console.log($scope.saveImportedImageDataResponse[0].userId);
			} else {
				console.log($scope.saveImportedImageDataResponse);
				console.log("Что-то не то в saveImportedImage");
			}
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
		})
		//console.log($("#owlCarouselProfile").data('owlCarousel'));
		$scope.showProfileCarouselPhoto(true);
	};
	$scope.saveProfileInfoChange = function () {
		if ($scope.birthdate === null || $scope.birthdate === "") {
			$scope.birthdatestr = new Date().toISOString().slice(0, 10);
			//console.log($scope.birthdatestr);
		} else {
			$scope.birthdatestr = $scope.birthdate.toISOString().slice(0, 10);
			//console.log($scope.birthdatestr);
		}
		$http.post("php/saveProfileInfo.php", {"name": $scope.name, "username": $scope.username, "userhash": $scope.userhash, "id": $scope.id, "surname": $scope.surname, "birthdate": $scope.birthdatestr, "street": $scope.street, "city": $scope.city, "province": $scope.province})
        .success(function (data, status, header, config) {
			//console.log("All done");
			$scope.saveProfileInfoDataResponse = data;
			//console.log($scope.saveProfileInfoDataResponse);
			$scope.setCookies($scope.saveProfileInfoDataResponse);
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
		})
	};
	//Сохранение аватара
	$scope.saveAvatar = function (imgSrc) {
		if (imgSrc.length < 1024000) {
		//console.log(imgSrc);
		$http.post("php/saveAvatar.php", {"id": $scope.id, "avatar": imgSrc, "userhash": $scope.userhash})
		.success(function (data, status, header, config) {
			$scope.avatarDataResponse = data;
			if ($scope.avatarDataResponse.userhash !== null && $scope.avatarDataResponse.userhash !== undefined) {
				$scope.setCookies($scope.avatarDataResponse);
		        $scope.SaveAvatarButton.innerHTML = $scope.SaveAvatarButton.innerHTML == "Сохранено"? "Сохранить фото": "Сохранено";
				$scope.SaveAvatarButtonDisabled = true;
			} else {
				console.log("Что-то не то в saveAvatar");
			}
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
		})
		} else {
			$scope.SaveAvatarButton.innerHTML = "Слишком большой размер";
			//console.log("Неверный размер");
		}
	};
	//Modal
	$scope.modal = document.getElementById('ProfileModal');
    $scope.modalImg = document.getElementById("img01");
    $scope.captionText = document.getElementById("ProfileCaption");
	$scope.imgdblClick = function (Url, Alt, ImageId) {
		var c;
		if (Url == "http://dummyimage.com/400x500?text=Photo") {
		} else{
		$scope.leftSliderformControl = document.getElementById("leftSlide").getElementsByClassName("form-control");
		for (c = 0; c < $scope.leftSliderformControl.length; c++){
			$scope.leftSliderformControl[c].style.opacity = "0";
			//console.log($scope.leftSliderformControl.length);
		};
		//$scope.formControl = document.getElementsByClassName("form-control");
		//console.log($scope.leftSliderformControl.length);
		//console.log("start");
		$scope.modal.style.display = "block";
		//console.log($scope.modal.style.display);
		$scope.modalImg.src = Url;
		$scope.modalImg.alt = Alt;
		//console.log(Alt);
		$scope.captionText.innerHTML = Alt;
		$scope.modalImg.id = ImageId;
	    }
	};
	$scope.modalClose = function () {
		var c;
		for (c = 0; c < $scope.leftSliderformControl.length; c++){
			$scope.leftSliderformControl[c].style.opacity = "1";
			//console.log($scope.leftSliderformControl.length);
		};
		$scope.modal.style.display = "none";
	}
	$scope.saveComment = function (z) {
		if ($("#owlCarouselProfile").data('owlCarousel') !== undefined && $("#owlCarouselProfile").data('owlCarousel') !== null) {
			$("#owlCarouselProfile").data('owlCarousel').destroy();
		}
		//console.log(z);
		//console.log($scope.modalImg.id);
		//console.log($scope.id);
		$http.post("php/saveImageComment.php", {"id": $scope.id, "imageId": $scope.modalImg.id, "imageComment": z})
        .success(function (data, status, header, config) {
			//console.log("All done");
			$scope.saveImageCommentDataResponse = data;
			if($scope.saveImageCommentDataResponse !== null && $scope.saveImageCommentDataResponse !== undefined){
				$scope.imagesCarouselProfileUrl = [
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
				];
				$scope.setImportedImage($scope.imagesCarouselProfileUrl);
				$scope.setImportedImage($scope.saveImageCommentDataResponse);
			    //console.log($scope.saveImportedImageDataResponse[1].imageUrl);
			}
			//$scope.setCookies($scope.saveProfileInfoDataResponse);
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
		})
		$scope.modalClose();
	};
	$scope.deleteImage = function () {
		if ($("#owlCarouselProfile").data('owlCarousel') !== undefined && $("#owlCarouselProfile").data('owlCarousel') !== null) {
			$("#owlCarouselProfile").data('owlCarousel').destroy();
		}
		//console.log($scope.modalImg.id);
		$http.post("php/deleteImage.php", {"id": $scope.id, "imageId": $scope.modalImg.id})
        .success(function (data, status, header, config) {
			//console.log("All done");
			$scope.deleteImageDataResponse = data;
			//console.log($scope.deleteImageDataResponse);
			if($scope.deleteImageDataResponse != "null" && $scope.deleteImageDataResponse != "undefined"){
				$scope.imagesCarouselProfileUrl = [
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
				];
				$scope.setImportedImage($scope.imagesCarouselProfileUrl);
				//console.log("ok");
				$scope.setImportedImage($scope.deleteImageDataResponse);
			    //console.log($scope.saveImportedImageDataResponse[1].imageUrl);
			} else {
				$scope.imagesCarouselProfileUrl = [
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null},
		{imageUrl: "img/400X500.png", userId: $scope.id, imageId: null, imageComment: null, imgloadDate: null}
				];
				$scope.setImportedImage($scope.imagesCarouselProfileUrl);
				console.log("Траблы в deleteImage либо сохраненных фото нет");
				//$location.path(' ');
			}
			//$scope.setCookies($scope.saveProfileInfoDataResponse);
		})
		.error(function(data, status) {
            console.error('Repos error', status, data);
		})
		$scope.modalClose();
		//$scope.owl.owlCarousel();
	}
}]);