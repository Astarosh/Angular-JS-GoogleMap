app.directive('helloMaps', function () {
	"use strict";
	return {
		restrict: 'E',
		link: function (scope, elem, attrs) {
			console.log("ok");
/*			scope.markers = [];
			var features = [];
			var infowindow = new google.maps.InfoWindow();
			var input = document.getElementById('pac-input');
			var searchBox = new google.maps.places.SearchBox(input);
			var myLatlng = new google.maps.LatLng(53.904, 27.544);
			var mapOptions = {
				zoom: 11
				, center: new google.maps.LatLng(53.904, 27.544)
				, mapTypeId: google.maps.MapTypeId.ROADMAP
				, mapTypeControlOptions: {
					style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
				}
			};*/
/*			var map = new google.maps.Map(elem[0], scope.mapOptions);
			google.maps.event.addListener(map, 'click', function (event) {
				placeMarker(event.latLng);
			});
			google.maps.event.addListener(map, 'click', function () {
				scope.infowindow.close();
			});*/
		/*	google.maps.event.addListener(map, 'click', function (event) {
				placeMarker(event.latLng);
			});
			google.maps.event.addListener(map, 'click', function () {
				infowindow.close();
			});
			//Загружаем файл
			map.data.loadGeoJson('stations.json');
			//Скрываем слой данных
			map.data.setStyle(function (feature) {
				return {
					visible: false, 
					//title:feature.getProperty('note'),
					//icon:feature.getProperty('type')
				};
			});
			//Поиск
			map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
			//Привязываем поиск к точке на карте
			map.addListener('bounds_changed', function () {
				searchBox.setBounds(map.getBounds());
			});
			searchBox.addListener('places_changed', function () {
				var places = searchBox.getPlaces();
				if (places.length == 0) {
					return;
				};
				//Убираем старую метку
				markers.forEach(function (marker) {
					marker.setMap(null);
				});
				markers = [];
				//Для каждого места ставим иконку и др свойства
				var bounds = new google.maps.LatLngBounds();
				places.forEach(function (place) {
					var icon = {
						url: "img/communitycentre.png"
						, size: new google.maps.Size(71, 71)
						, origin: new google.maps.Point(0, 0)
						, anchor: new google.maps.Point(17, 34)
						, scaledSize: new google.maps.Size(25, 25)
					};
					//Создаем маркер
					markers.push(new google.maps.Marker({
						map: map
						, icon: icon
						, title: place.name
						, position: place.geometry.location
					}));
					if (place.geometry.viewport) {
						bounds.union(place.geometry.viewport);
					}
					else {
						bounds.extend(place.geometry.location);
					}
				});
				map.fitBounds(bounds);
			});
			//Конец поиска
			//Получение куков
			function get_cookie(cookie_name) {
				var results = document.cookie.match('(^|;) ?' + cookie_name + '=([^;]*)(;|$)');
				if (results) return (unescape(results[2]));
				else return null;
			};
			//Функция для добавления маркера на карту
			function placeMarker(location) {
				var marker = new google.maps.Marker({
					position: location
					, map: map
					, animation: google.maps.Animation.DROP
					, title: 'Uluru (Ayers Rock)'
				});
				var userIDcookie = get_cookie("id");
				var markQty = get_cookie("markQty");
				var userStatus = get_cookie("status");
				var infowindow = new google.maps.InfoWindow();
				if (markQty == 0 || userStatus == 1) {
					infowindow.setContent('<form id="ballon" method="POST" action="addFeature.php">' + '<input required id="lng" name="lat" value=' + location.lng() + ' style="display:none" />' + '<input required id="lat" name="lng" value=' + location.lat() + ' style="display:none" />' + '<label style="color:black">Название:</label> <input required type="text" class="input-medium" id="eventname" name="name_text" /><br />' + '<label style="color:black">Подсказка:</label> <input required type="text" id="eventhelp" class="input-medium" name="hint_text" /><br />' + '<label style="color:black">Балун:</label> <input required type="text" class="input-medium" name="balloon_text" /><br />' + '<div class="control-group"><label style="color:black">Значок метки:</label>' + '<div class="input-prepend"><span class="add-on"><img src="img/restaurant.png" style="height: 20px" /></span>' + '<select name="image" id="eventtype" class="span2" >' + '<option data-path="img/bar.png" value="img/bar.png">Бар</option>' + '<option data-path="img/coffe.png" value="img/coffee.png">Кафе</option>' + '<option data-path="img/restaurant.png" value="img/restaurant.png">Ресторан</option>' + '</select>' + '</div>' + '</div>' + '<button class="btn btn-success">Сохранить</button>' + '</form>' + '<button id="deletemarker">Отмена</button>')
				}
				else {
					infowindow.setContent('<form id="ballon">' + '<input required id="lng" name="lat" value=' + location.lng() + ' style="display:none" />' + '<input required id="lat" name="lng" value=' + location.lat() + ' style="display:none" />' + '<label style="color:black">Название:</label> <input required type="text" class="input-medium" id="eventname" name="name_text" /><br />' + '<label style="color:black">Подсказка:</label> <input required type="text" id="eventhelp" class="input-medium" name="hint_text" /><br />' + '<label style="color:black">Балун:</label> <input required type="text" class="input-medium" name="balloon_text" /><br />' + '<div class="control-group"><label style="color:black">Значок метки:</label>' + '<div class="input-prepend"><span class="add-on"><img src="img/restaurant.png" style="height: 20px" /></span>' + '<select name="image" id="eventtype" class="span2" >' + '<option data-path="img/bar.png" value="img/bar.png">Бар</option>' + '<option data-path="img/coffe.png" value="img/coffee.png">Кафе</option>' + '<option data-path="img/restaurant.png" value="img/restaurant.png">Ресторан</option>' + '</select>' + '</div>' + '</div>' + '</form>' + '<button id="deletemarker">Отмена</button>')
				};
				infowindow.open(map, marker);
				marker.addListener('click', function () {
					infowindow.open(map, marker);
				});
				document.getElementById("deletemarker").onclick = deleteMark;

				function deleteMark() {
					marker.setMap(null)
				};
				google.maps.event.addListener(map, 'click', function () {
					infowindow.close();
				});
				markers.push(marker);
			};
			//Кластеризация
			function featurecluster() {
				var markers = [];
				var bars = [];
				var restaurants = [];
				var caffees = [];
				var allmarkers = [];
				//Спрятать маркеры определенного типа
				document.getElementById("showBars").onclick = function showBars() {
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].icon == "img\/bar.png") {
							markers[i].setVisible(true);
							bars.push(markers[i]);
						}
						else {
							markers[i].setVisible(false);
						}
					};
					markerClusterer.clearMarkers();
					markerClusterer = new MarkerClusterer(map, bars, {
						maxZoom: 20
						, gridSize: 60
						, averageCenter: true
					})
				};
				document.getElementById("showRestaurant").onclick = function showRestaurants() {
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].icon == "img\/restaurant.png") {
							markers[i].setVisible(true);
							restaurants.push(markers[i]);
						}
						else {
							markers[i].setVisible(false);
						}
					};
					markerClusterer.clearMarkers();
					markerClusterer = new MarkerClusterer(map, restaurants, {
						maxZoom: 20
						, gridSize: 60
						, averageCenter: true
					})
				};
				document.getElementById("showCaffee").onclick = function showCoffee() {
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].icon == "img\/coffee.png") {
							markers[i].setVisible(true);
							caffees.push(markers[i]);
						}
						else {
							markers[i].setVisible(false);
						}
					};
					markerClusterer.clearMarkers();
					markerClusterer = new MarkerClusterer(map, caffees, {
						maxZoom: 20
						, gridSize: 60
						, averageCenter: true
					})
				};
				document.getElementById("showAll").onclick = function showAll() {
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].icon) {
							markers[i].setVisible(true);
							allmarkers.push(markers[i]);
						}
						else {
							markers[i].setVisible(false);
						}
					};
					markerClusterer.clearMarkers();
					markerClusterer = new MarkerClusterer(map, allmarkers, {
						maxZoom: 20
						, gridSize: 60
						, averageCenter: true
					})
				};
				//Получение данных geoJson и преобразование их в маркеры, добавление их в массив
				map.data.forEach(function (feature) {
					var Latlng = feature.getGeometry().get();
					var marker = new google.maps.Marker({
						position: Latlng
						, icon: feature.getProperty('type')
						, title: "ululu"
						, customInfo1: feature.getProperty("userid")
						, customInfo2: feature.getId()
						, customInfo3: feature.getProperty("name")
					});
					markers.push(marker);
					marker.addListener('click', function () {
						map.setZoom(12);
						map.setCenter(marker.getPosition());
						var userIDcookie = get_cookie("id");
						if (marker.customInfo1 == userIDcookie) {
							infowindow.setContent("<form action='deleteFeature.php' method='POST'>" + "<input id='featureID' name='featureID' value=" + marker.customInfo2 + " />" + "<div style='color:black' style='width:150px; text-align: center;'>" + marker.customInfo3 + "</div>" + "<button id='deleteFeature'>Удалить</button>" + "</form>");
						}
						else {
							infowindow.setContent("<div style='width:150px; text-align: center; color:black'>" + marker.customInfo3 + "</div>");
						};
						infowindow.open(map, marker);
					});
				});
				//Сама кластеризация        
				markerClusterer = new MarkerClusterer(map, markers, {
					maxZoom: 20
					, gridSize: 60
					, averageCenter: true
				});
			};
			setTimeout(function () {
				featurecluster();
			}, 1000);*/
		}
	};
});