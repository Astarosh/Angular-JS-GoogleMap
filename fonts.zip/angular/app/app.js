var app = angular.module("app", ["ngRoute", "ngCookies", "matchMedia", "appFilereader", "vcRecaptcha", "ui.bootstrap"]);
app.config(["$routeProvider", "$locationProvider", function($routeProvider, $locationProvider){
	$routeProvider
		.when('/', {
      templateUrl: 'template/home.html'
    })
		.when('/about', {
		templateUrl: 'template/about.html'
	})
		.when('/map', {
		templateUrl: 'template/map.html'
	})
		.when('/profile', {
		templateUrl: 'template/profile.html'
	})
		.when('/registration', {
		templateUrl: 'template/registration.html'
	}).otherwise('/');
	$locationProvider.html5Mode(true);
}]);
