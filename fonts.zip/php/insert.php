<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$email = mysqli_real_escape_string($conn, $data->email);
$password = mysqli_real_escape_string($conn, $data->password);
$userhash = mysqli_real_escape_string($conn, $data->userhash);
$id = mysqli_real_escape_string($conn, $data->id);
    //Вытаскиваем из БД запись, у которой логин равняется введенному
$query ="SELECT userhash FROM mappersondata WHERE id='$id'";
$result = mysqli_query($conn, $query);
$data1 = mysqli_fetch_assoc($result);
$query1 ="SELECT password FROM mappersondata WHERE email='$email'";
$result1 = mysqli_query($conn, $query1);
$data2 = mysqli_fetch_assoc($result1);
//Сравниваем хеши
if($data1["userhash"] == $userhash){
	//Генерируем случайное число и шифруем его
	$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
	//Записываем в БД новый хеш авторизации
	$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now() WHERE id='$id'";
	//Проверка записи
	if (mysqli_query($conn, $hashquery)) {
		$query2 ="SELECT id, status, userhash, markQty, name, surname, birthdate, avatar, lastLogin, email, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE id='$id'";
		$result2 = mysqli_query($conn, $query2);
		$data3 = mysqli_fetch_assoc($result2);
		echo json_encode($data3, JSON_UNESCAPED_UNICODE);
	}
	else {
			echo "Error updating record: " . mysqli_error($conn);
	};
} elseif (password_verify($password, $data2["password"])){
	//Генерируем случайное число и шифруем его
        $hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
    //Записываем в БД новый хеш авторизации
        $hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now() WHERE email='$email'";
	//Проверка записи
        if (mysqli_query($conn, $hashquery)) {
		    $query3 ="SELECT id, status, userhash, markQty, name, surname, birthdate, avatar, lastLogin, email, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE email='$email'";
		    $result3 = mysqli_query($conn, $query3);
		    $data4 = mysqli_fetch_assoc($result3);
		    echo json_encode($data4, JSON_UNESCAPED_UNICODE);
	    }
	    else {
            echo "Error updating record: " . mysqli_error($conn);
	    };
	    exit();
} else {
		$passval = "Неверный пароль";
		echo ($passval);
};
?>