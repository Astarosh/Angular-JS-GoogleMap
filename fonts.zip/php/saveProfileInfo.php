<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id =  mysqli_real_escape_string($conn, $data->id);
$userhash =  mysqli_real_escape_string($conn, $data->userhash);
$firstname = mysqli_real_escape_string($conn, $data->name);
$username = mysqli_real_escape_string($conn, $data->username);
$surname = mysqli_real_escape_string($conn, $data->surname);
$birthdate = mysqli_real_escape_string($conn, $data->birthdate);
$street = mysqli_real_escape_string($conn, $data->street);
$city = mysqli_real_escape_string($conn, $data->city);
$province = mysqli_real_escape_string($conn, $data->province);
$err = array();
    // проверяем имя
    if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$firstname))
    {
        $err[] = "Имя может состоять только из букв английского алфавита, цифр и кириллицы";
    }     
	//проверяем username
	if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$username))
    {
        $err[] = "username может состоять только из букв английского алфавита, цифр и кириллицы";
    } 
    //проверяем фамилию
	if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$surname))
    {
        $err[] = "Фамилия может состоять только из букв английского алфавита, цифр и кириллицы";
    } 
	//проверяем дату рождения
		if(!preg_match("/(19|20)\d\d-((0[1-9]|1[012])-(0[1-9]|[12]\d)|(0[13-9]|1[012])-30|(0[13578]|1[02])-31)/",$birthdate))
    {
        $err[] = "Дата может состоять только из букв английского алфавита, цифр и кириллицы";
    }
	//проверяем улицу
		if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]*$/u",$street))
    {
        $err[] = "Страна может состоять только из букв английского алфавита, цифр и кириллицы";
    }
	//проверяем город
		if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$city))
    {
        $err[] = "Город может состоять только из букв английского алфавита, цифр и кириллицы";
    }
    //проверяем область
		if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$province))
    {
        $err[] = "Город может состоять только из букв английского алфавита, цифр и кириллицы";
    }
$query ="SELECT userhash FROM mappersondata WHERE id='$id'";
$result = mysqli_query($conn, $query);
$data1 = mysqli_fetch_assoc($result);
if($data1["userhash"] == $userhash){
	//Генерируем случайное число и шифруем его
	$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
	//Записываем в БД новый хеш авторизации
	$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', name='$firstname', username='$username', surname='$surname', birthdate='$birthdate', street='$street', city='$city', province='$province' WHERE id='$id'";
	//Проверка записи
	if (mysqli_query($conn, $hashquery)) {
		$query2 ="SELECT id, status, userhash, markQty, name, surname, birthdate, avatar, lastLogin, email, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE id='$id'";
		$result2 = mysqli_query($conn, $query2);
		$data3 = mysqli_fetch_assoc($result2);
		echo json_encode($data3, JSON_UNESCAPED_UNICODE);
			//echo "Record updated successfully";
	}
	else {
			echo "Error updating record: " . mysqli_error($conn);
	}
}
?>