<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id = mysqli_real_escape_string($conn, $data->id);
$imageId = mysqli_real_escape_string($conn, $data->imageId);
$query1 = "DELETE FROM images WHERE imageId = '$imageId'";
if(mysqli_query($conn, $query1)){
	$query ="SELECT * FROM images WHERE userId='$id' ORDER BY imgLoadDate ASC";
	$rows = array();
	$result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result)!==0){
	    while($array = mysqli_fetch_assoc($result)){
	        $row[] = $array;
	} 
	echo json_encode($row, JSON_UNESCAPED_UNICODE);
	} else {
	echo "null";
	}
}
else {
	//echo "Error updating record: " . mysqli_error($conn);
}
?>