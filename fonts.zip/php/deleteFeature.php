<?php
require("bd.php");
$featureID=$_POST["featureID"];
$array = json_decode(file_get_contents('stations.json'),true);
$i=0;
for($i;$i<count($array["features"]);$i++){
	if($array["features"][$i]["id"] == $featureID){
    array_splice($array["features"], $i, 1);	    	
	};
};
$result = json_encode($array, JSON_PRETTY_PRINT, JSON_UNESCAPED_UNICODE);
file_put_contents('stations.json', $result);
$delSQL = "DELETE FROM markerstable WHERE eventID = '$featureID'";    
if (mysqli_query($conn, $delSQL)) {   
    echo "Record updated successfully";	
	$cookie_name4 = "markQty";
	$cookie_value4 = $_COOKIE["markQty"]-1;
    setcookie($cookie_name4, $cookie_value4, time()+60*60*24*30);
}  
else {
   echo "Error updating record: " . mysqli_error($conn);
};
$userid=$_COOKIE["id"];
$sqlUPD = "UPDATE mappersondata SET markQty=markQty-1 WHERE id='$userid'"; 
if (mysqli_query($conn, $sqlUPD)) {   
    echo "Record updated successfully";
	//header("Location: map2.html");
    exit();
}  
else {
   echo "Error updating record: " . mysqli_error($conn);
};

?>