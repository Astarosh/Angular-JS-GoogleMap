<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$email = mysqli_real_escape_string($conn, $data->email);
$name = mysqli_real_escape_string($conn, $data->name);
$surname = mysqli_real_escape_string($conn, $data->surname);
$userhash = mysqli_real_escape_string($conn, $data->userhash);
$query ="INSERT INTO mappersondata (email, name, surname) VALUES ('$email', '$name', '$surname')";
if (mysqli_query($conn, $query)) {
		$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
		//Записываем в БД новый хеш авторизации
		$hashquery = "UPDATE mappersondata SET userhash = '$hashrandom', lastLogin = now() WHERE email = '$email'";
		//Проверка записи
		if (mysqli_query($conn, $hashquery)) {
			$query2 ="SELECT id, status, markQty, name, userhash, surname, birthdate, avatar, email, city, lastLogin, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE email='$email'";
			$result = mysqli_query($conn, $query2);
			$data = mysqli_fetch_assoc($result);
			echo json_encode($data, JSON_UNESCAPED_UNICODE);
		} else {
				echo "Error updating record: " . mysqli_error($conn);
		};
} else {
	$query1 ="SELECT userhash FROM mappersondata WHERE email='$email'";
	$result = mysqli_query($conn, $query1);
	$data1 = mysqli_fetch_assoc($result);
	if($data1["userhash"] == $userhash){
		$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
		//Записываем в БД новый хеш авторизации
		$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now()  WHERE email = '$email'";
		//Проверка записи
		if (mysqli_query($conn, $hashquery)) {
			$query2 ="SELECT id, status, markQty, name, userhash, surname, birthdate, avatar, email, lastLogin, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE email='$email'";
			$result = mysqli_query($conn, $query2);
			$data = mysqli_fetch_assoc($result);
			echo json_encode($data, JSON_UNESCAPED_UNICODE);
		} else {
				echo "Error updating record: " . mysqli_error($conn);
		};
	} else {
		$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);     
		//Записываем в БД новый хеш авторизации
		$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now() WHERE email = '$email'";
		//Проверка записи
		if (mysqli_query($conn, $hashquery)) {
			$query2 ="SELECT id, status, markQty, name, userhash, surname, avatar, birthdate, email, lastLogin, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE email='$email'";
			$result = mysqli_query($conn, $query2);
			$data = mysqli_fetch_assoc($result);
			echo json_encode($data, JSON_UNESCAPED_UNICODE);
		}
		else {
				echo "Error updating record: " . mysqli_error($conn);
		};
	}
}; 
exit();
?>