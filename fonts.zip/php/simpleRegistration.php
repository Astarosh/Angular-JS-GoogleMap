<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$firstname = mysqli_real_escape_string($conn, $data->name);
$lastname = mysqli_real_escape_string($conn, $data->lastname);
$password = mysqli_real_escape_string($conn, $data->password);
$email = mysqli_real_escape_string($conn, $data->email);
    $err = array();
    // проверяем имя
    if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$firstname))
    {
        $err[] = "Имя может состоять только из букв английского алфавита, цифр и кириллицы";
    }     
//проверяем фамилию
	if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$lastname))
    {
        $err[] = "Фамилия может состоять только из букв английского алфавита, цифр и кириллицы";
    } 
//проверяем пароль
	if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$password))
    {
        $err[] = "пароль может состоять только из букв английского алфавита, цифр и кириллицы";
    }
	//проверяем email
		if(!preg_match("/^[-\w.]+@([A-z0-9][-A-z0-9]+\.)+[A-z]{2,4}$/u",$email))
    {
        $err[] = "Email может состоять только из букв английского алфавита, цифр и кириллицы";
    }
    //проверяем, не сущестует ли пользователя с таким email
    $query = "SELECT email FROM mappersondata WHERE email='$email'";
    if (mysqli_query($conn, $query)) {
    //echo "Record updated successfully";
	} else {
    echo "Error updating record: " . mysqli_error($conn);
	};
    if($query > 0) {
        $err[] = "Пользователь с таким логином уже существует в базе данных";
    }
    if(count($err) == 0) {
        $password = password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO mappersondata SET name='$firstname', password='$password', surname='$lastname', email='$email'";
		if (mysqli_query($conn, $sql)) {
			$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);
			$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now() WHERE email='$email'";
			if (mysqli_query($conn, $hashquery)) {
				$query ="SELECT id, status, userhash, markQty, name, surname, birthdate, lastLogin, email, city, citylat, citylon, regdate, username, street, province FROM mappersondata WHERE email='$email'";
				$result = mysqli_query($conn, $query);
				$data1 = mysqli_fetch_assoc($result);
				echo json_encode($data1, JSON_UNESCAPED_UNICODE);
			}
			else {
					echo "Error updating record: " . mysqli_error($conn);
			};
		} else {
		echo "Error updating record: " . mysqli_error($conn);
		};
	} else {
		foreach($err AS $error) {
            print $error."<br>";
        }
    }
?>