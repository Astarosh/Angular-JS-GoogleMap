<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id = mysqli_real_escape_string($conn, $data->id);
$imageComment = mysqli_real_escape_string($conn, $data->imageComment);
$imageId = mysqli_real_escape_string($conn, $data->imageId);
$query = "UPDATE images SET imageComment='$imageComment'  WHERE imageId='$imageId'";
if(mysqli_query($conn, $query)){
	$query ="SELECT * FROM images WHERE userId='$id' ORDER BY imgLoadDate ASC";
	$rows = array();
	$result = mysqli_query($conn, $query);
	while($array = mysqli_fetch_assoc($result)){
	$row[] = $array;
	}
	echo json_encode($row, JSON_UNESCAPED_UNICODE);
}
else {
	echo "Error updating record: " . mysqli_error($conn);
}
?>