<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id = mysqli_real_escape_string($conn, $data->id);
$userhash = mysqli_real_escape_string($conn, $data->userhash);
$eventName = mysqli_real_escape_string($conn, $data->eventName);
$eventDate = mysqli_real_escape_string($conn, $data->eventDate);
$additionlInfo = mysqli_real_escape_string($conn, $data->additionInfo);
$eventType = mysqli_real_escape_string($conn, $data->eventType);
$eventLat = mysqli_real_escape_string($conn, $data->eventLat);
$eventLng = mysqli_real_escape_string($conn, $data->eventLng);
$eventTime = mysqli_real_escape_string($conn, $data->eventTime);
$err = array();
    // проверяем имя
if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$eventName))
{
    $err[] = "Имя может состоять только из букв английского алфавита, цифр и кириллицы";
}     
//проверяем инфу
if(!preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]+$/u",$additionlInfo))
{
	$err[] = "пароль может состоять только из букв английского алфавита, цифр и кириллицы";
}
$query ="SELECT userhash FROM mappersondata WHERE id='$id'";
$result = mysqli_query($conn, $query);
$data1 = mysqli_fetch_assoc($result);
if(count($err) == 0 && $id != "undefined" && $id != "null") {
    $hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);
	$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', lastLogin = now() WHERE id='$id'";
	if (mysqli_query($conn, $hashquery)) {
        $sql = "INSERT INTO markerstable SET eventname='$eventName', eventtype='$eventType', eventDate='$eventDate', userID='$id', eventlat='$eventLat', eventlng='$eventLng', eventhelp='$additionlInfo', eventTime= '$eventTime'";
	    if (mysqli_query($conn, $sql)) {
			$eventID = mysqli_insert_id($conn);
			$array = json_decode(file_get_contents('stations.json'),true);
            $jsonvalue= array(
				       'type' => 'Feature',	
                       'id'=>$eventID,					   
                       'geometry' => array(
                       'type' => 'Point',
                       'coordinates' =>array(floatval($eventLng), floatval($eventLat))
                       ),
                       'properties' => array(
					   'userid'=>$id,
				       'name'=>$eventName,
                       'type' => $eventType,
                       'note' => $additionlInfo,
					   'eventdate' => $eventDate,
					   'eventTime' => $eventTime
                ));
            $array["features"][count($array["features"])]=$jsonvalue;			
			$result2 = json_encode($array, JSON_PRETTY_PRINT, JSON_UNESCAPED_UNICODE);
			file_put_contents('stations.json', $result2);
			echo $result2;
			echo "All ok";
		} else {
		echo "Error updating record: " . mysqli_error($conn);
		};
	} else {
		echo "Error updating record: " . mysqli_error($conn);
	};
} else {
	foreach($err AS $error) {
        print $error."<br>";
    }
}
?>