<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id = mysqli_real_escape_string($conn, $data->id);
$url1 = mysqli_real_escape_string($conn, $data->url1);
$url2 = mysqli_real_escape_string($conn, $data->url2);
$url3 = mysqli_real_escape_string($conn, $data->url3);
$url4 = mysqli_real_escape_string($conn, $data->url4);
$url5 = mysqli_real_escape_string($conn, $data->url5);
$query1 = "INSERT INTO images (imageUrl, userId) VALUES ('$url1', '$id'), ('$url2', '$id'), ('$url3', '$id'), ('$url4', '$id'), ('$url5', '$id')";
if(mysqli_query($conn, $query1)){
	$query2 = "DELETE FROM images WHERE imageUrl = ''";
	mysqli_query($conn, $query2);
	$query ="SELECT * FROM images WHERE userId='$id' ORDER BY imgLoadDate DESC";
	$rows = array();
	$result = mysqli_query($conn, $query);
	while($array = mysqli_fetch_assoc($result)){
	$row[] = $array;
	}
	echo json_encode($row, JSON_UNESCAPED_UNICODE);
}
else {
		echo "Error updating record: " . mysqli_error($conn);
}
?>