<?php
require("bd.php");
$data = json_decode(file_get_contents("php://input"));
$id = mysqli_real_escape_string($conn, $data->id);
$userhash = mysqli_real_escape_string($conn, $data->userhash);
$query ="SELECT userhash FROM mappersondata WHERE id='$id'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);
if($data["userhash"] == $userhash){
	$query2 ="SELECT * FROM images WHERE userId='$id' ORDER BY imgLoadDate DESC";
	$rows = array();
	$result2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($result2)!==0){
		while($array = mysqli_fetch_assoc($result2)){
		$row[] = $array;
		} 
		echo json_encode($row, JSON_UNESCAPED_UNICODE);
	} else {
		echo "null";
	}
} else {
	echo "Неверный хеш";
}
?>