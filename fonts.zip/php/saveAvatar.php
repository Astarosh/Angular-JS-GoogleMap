<?php
require("bd.php");
/*function generateCode($length=6) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHI JKLMNOPRQSTUVWXYZ0123456789";
    $code = "";
    $clen = strlen($chars) - 1;
    while (strlen($code) < $length) {
            $code .= $chars[mt_rand(0,$clen)];
    }
    return $code;
};*/
$data = json_decode(file_get_contents("php://input"));
$avatar = mysqli_real_escape_string($conn, $data->avatar);
$id = mysqli_real_escape_string($conn, $data->id);
$userhash = mysqli_real_escape_string($conn, $data->userhash);
$query ="SELECT userhash FROM mappersondata WHERE id='$id'";
$result = mysqli_query($conn, $query);
$data1 = mysqli_fetch_assoc($result);
if($data1["userhash"] == $userhash){
	$hashrandom = password_hash(generateCode(10),PASSWORD_DEFAULT);
	$hashquery = "UPDATE mappersondata SET userhash='$hashrandom', avatar = '$avatar' WHERE id='$id'";
	if (mysqli_query($conn, $hashquery)) {
		$query ="SELECT avatar, userhash FROM mappersondata WHERE id='$id'";
		$result = mysqli_query($conn, $query);
		$data1 = mysqli_fetch_assoc($result);
		echo json_encode($data1, JSON_UNESCAPED_UNICODE);
	} else {
		echo "Error updating record: " . mysqli_error($conn);
	}
//$query ="SELECT password FROM mappersondata WHERE email='$email'";
//$result = mysqli_query($conn, $query);
//$data = mysqli_fetch_assoc($result);
} else {
	echo "Error updating record: " . mysqli_error($conn);
	echo "Invalid user";
}
?>