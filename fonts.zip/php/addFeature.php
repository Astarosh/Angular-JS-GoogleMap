<?php
require("bd.php");
$lat=$_POST["lat"];
$lng=$_POST["lng"];
$name_text=$_POST["name_text"];
$hint_text=$_POST["hint_text"];
$balloon_text=$_POST["balloon_text"];
$eventtype=$_POST["image"];
$userid=$_COOKIE["id"];
$sql = "INSERT INTO markerstable SET eventname='$name_text',eventhelp='$hint_text',eventlat='$lat',	eventlng='$lng',eventtype='$eventtype', userID='$userid'";  	
	//Проверка записи
if (mysqli_query($conn, $sql)) {   
   echo "Record updated successfully";
   //header("Location: geoJSONcreate.php"); exit();
}  
else {
   echo "Error updating record: " . mysqli_error($conn);
};
$eventID = mysqli_insert_id($conn);
$array = json_decode(file_get_contents('stations.json'),true);
$jsonvalue= array(
				       'type' => 'Feature',	
                       'id'=>$eventID,					   
                       'geometry' => array(
                       'type' => 'Point',
                       'coordinates' =>array(floatval($lat), floatval($lng))
                       ),
                       'properties' => array(
					   'userid'=>$userid,
				       'name'=>$name_text,
                       'type' => $eventtype,
                       'note' => $hint_text					   
                ));
$array["features"][count($array["features"])]=$jsonvalue;			
$result = json_encode($array, JSON_PRETTY_PRINT, JSON_UNESCAPED_UNICODE);
file_put_contents('stations.json', $result);
$sql1 = "UPDATE mappersondata SET markQty=markQty+1 WHERE id='$userid'"; 	
	//Проверка записи
if (mysqli_query($conn, $sql1)) {		
	    $cookie_name4 = "markQty";
	    $cookie_value4 = $_COOKIE["markQty"]+1;
        setcookie($cookie_name4, $cookie_value4, time()+60*60*24*30);
        if(isset($_COOKIE[$cookie_name4])) {
            echo "Cookie '".$cookie_name4."' is set!<br>";
            echo "Value is: " . $_COOKIE["markQty"];
        }; 		
   echo "Record updated successfully";
   //header("Location: map2.html");  
   exit();
}  
else {
   echo "Error updating record: " . mysqli_error($conn);
};

?>